#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "SDL/SDL.h"

#include <grplib/gr8.h>
#include <grplib/grp.h>
#include <grplib/usegrp.h>
#include <grplib/palette.h>

#include "mytime.h"

//max gradation for red,green,blue,shadows,white
#define MAXGRD 32
#define MAXPLAYERCOLOR  15
#define MONOPLAYERCOLOR (MAXPLAYERCOLOR+1)

#define ENDPLAYERCOLOR  MONOPLAYERCOLOR

#define	XW	640
#define	YW	480

//this table needed to change output grp-picture (more red,green,....)
char *_tored_,*_togreen_,*_toblue_,*_toblack_,*_towhite_,*_tomono_;

//my palette
char palette[256*3];

//my usercolor
char dependencycolor[256];

//sdl surface
SDL_Surface *sdlsurface;

//key pressed
char keyactive,lastkey;

//active window or not
int active;
//====================================
//set palette now
//========================================
int LoadingAllPalettes(void)
{
    int i,j;
    //load our palette
    FILE *f = fopen("pal/palette.dat","rb");	
    if (!f)
	printf("file pal/palette.dat not found\n");
    else
    {
	fread(palette,3,256,f);
	fclose(f);
    }
    char *transp = (char *)malloc(256*256);
    //load or create our transparent table from palette
    f = fopen("pal/transptable.dat","rb");
    if (!f)
    {
	printf("file pal/transptable.dat not found\nCreating...");
	fflush(stdout);
	//create transparent table
	CreateTRColors(palette,transp);
	printf("\ndone. now saveing to file pal/transptable.dat\n");
	f = fopen("pal/transptable.dat","wb");
	//save this table to file for future use
	fwrite(transp,256,256,f);
    }
    else
	fread(transp,256,256,f);
    fclose(f);
    //set transparent table to use by grp's function
    SetTranspTable(transp);
    //load user color from file
    f = fopen("pal/usercolor.dat","rb");
    if (!f)
	printf("file pal/usercolor.dat not found\n");
    else
    {
	fread(dependencycolor,1,256,f);
	fclose(f);
        //set 16 usercolors from first 0
	//dependencycolor constain 16*8 bytes
	//and 'SetUserPlayerColors' change 8-15 indexes(pallette remain untouched)
	SetUserPlayerColors(0,16,dependencycolor);
	//set first 16 player colors
    }
    //create black table(for shadows)
    _toblack_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/toblack.grd","rb");	//table of decrement colors(for shadows)
    if (!f)
    {
	printf("file pal/toblack.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(0,0,0),MAKERGB(0,0,0), MAXGRD,_toblack_);
	printf("\ndone. now saveing to file pal/toblack.grd\n");
	f = fopen("pal/toblack.grd","wb");
	fwrite(_toblack_,MAXGRD,256,f);
    }
    else
	fread(_toblack_,MAXGRD,256,f);
    fclose(f);
    
    //create white table(for light if needed)
    
    _towhite_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/towhite.grd","rb");	//table of increment colors up to white
    if (!f)
    {
	printf("file pal/towhite.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(240,240,240),MAKERGB(240,240,240),
		MAXGRD,_towhite_);
	printf("\ndone. now saveing to file pal/towhite.grd\n");
	f = fopen("pal/towhite.grd","wb");
	fwrite(_towhite_,MAXGRD,256,f);
    }
    else
	fread(_towhite_,MAXGRD,256,f);
    fclose(f);

    //create red table(for bloodlust if needed)
    _tored_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/tored.grd","rb");	//table of increment colors up to red
    if (!f)
    {
	printf("file pal/tored.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(120,0,0),MAKERGB(244,228,144),
		MAXGRD,_tored_);
	printf("\ndone. now saveing to file pal/tored.grd\n");
	f = fopen("pal/tored.grd","wb");
	fwrite(_tored_,MAXGRD,256,f);
    }
    else
	fread(_tored_,MAXGRD,256,f);
    fclose(f);
    
    //create green table
    _togreen_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/togreen.grd","rb");	//table of increment colors up to green
    if (!f)
    {
	printf("file pal/togreen.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(0,140,0),MAKERGB(252,252,56),
		MAXGRD,_togreen_);
	printf("\ndone. now saveing to file pal/togreen.grd\n");
	f = fopen("pal/togreen.grd","wb");
	fwrite(_togreen_,MAXGRD,256,f);
    }
    else
	fread(_togreen_,MAXGRD,256,f);
    fclose(f);
    
    //create blue table
    _toblue_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/toblue.grd","rb");	//table of increment colors up to blue
    if (!f)
    {
	printf("file pal/toblue.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(0,60,150),MAKERGB(204,248,248),
		MAXGRD,_toblue_);
	printf("\ndone. now saveing to file pal/toblue.grd\n");
	f = fopen("pal/toblue.grd","wb");
	fwrite(_toblue_,MAXGRD,256,f);
    }
    else
	fread(_toblue_,MAXGRD,256,f);
    fclose(f);

    _tomono_ = (char *)malloc(256);//allocate memory for monocrome table
    
    f = fopen("pal/tomono.grd","rb");	//table of monocrome indexes in same palette
    if (!f)
    {
	printf("file pal/tomono.grd not found\nCreating...");
	fflush(stdout);
	CreateMono(palette,_tomono_);
	printf("\ndone. now saveing to file pal/tomono.grd\n");
	f = fopen("pal/tomono.grd","wb");
	fwrite(_tomono_,1,256,f);
    }
    else
	fread(_tomono_,1,256,f);
    SetPlayerColors(MONOPLAYERCOLOR,1,0,256,_tomono_);
    //set 17-player all 256 colors in mono gradation
    //if on call putgrp's  unitcolor=MONOPLAYERCOLOR we see sprite monocromatic

    fclose(f);
    return 0;
}
//====================================
//===========================================
int main(int count,char *argv[])
{
    GRPFILE *mygrp;		//need for loadgrp
    if (count != 2)
    {
	printf("usage:%s filename.grp\n",argv[0]);
	return -1;
    }
    //now we load pallete and set user colors(8-15 indexes in palette)
    //calculate all tables(glow,shadow,etc..)
    //initialize grp-library with 640x480
    if (InitGrpLib(XW,YW))
    {
	printf("error initialize grplib\n");
	return -1;
    }
    //load grp from file and fill mygrp structure with all grp data
    if (loadgrp(argv[1],&mygrp))
    {
	printf("error occured then loading %s file\n",argv[1]);
	return -2;	
    }
    //sdl initialization
    if (LoadingAllPalettes())
    {
	printf("error to load palettes files\n");
    }
//    activatepallette(palette);// set palette (now my window use my palette)

    int exitflag=0,colors=0,gradation=0;
    active = 1;//active window or not
    printf("press \n1/2- to change color of unit\n3/4 - next/prev texture grp\n"
	   "9/0 - +/- gradation intencity(0..%d)\n" 
	   "ESC to exit\n",MAXGRD-1);
    //allocation memory for background , to put fast
    char *background=(char *)malloc(XW*YW);
    SetVideoBuffer(background);//we may call this function any time we need
					//this function change pointer to memory
					//where putgrp's function place sprites
    
    //set background 
    for (int i=0;i<YW;i++)
        for (int j=0;j<XW;j++)
	    background[i*XW+j]=(char)j;
    //get size of grp-images
    int xsize = mygrp->SizeX;
    int ysize = mygrp->SizeY;
    printf("grp with format:\nmax textures=%d\nmaxsizex=%d\nmaxsizey=%d\n",
	    mygrp->CountPictures,xsize,ysize);
    //set first-see values

    int nrsprite = 0,unitcolor=0,grdfactor=MAXGRD/2;
    long long a;
    int i;
    a=getmicrosecs();
    for (i=0;i<100000;i++)
    {
	putgrpspr(0,0,mygrp,GLOW,255,0,_toblue_,0);
    }    
    a=getmicrosecs()-a;
    printf("average time execute=%d\n\n",a);
    free(background);		 //free memory allocated for background
    freegrp(mygrp);		 //free memory allocated by loadgrp	
    QuitGrpLib();		 //exit grplib
    return 0;
}


#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "SDL/SDL.h"

#include <grplib/gr8.h>
#include <grplib/grp.h>
#include <grplib/usegrp.h>
#include <grplib/palette.h>

//max gradation for red,green,blue,shadows,white
#define MAXGRD 32
#define MAXPLAYERCOLOR  15
#define MONOPLAYERCOLOR (MAXPLAYERCOLOR+1)

#define ENDPLAYERCOLOR  MONOPLAYERCOLOR

#define	XW	640
#define	YW	480

int DELTAX,DELTAY;

//this table needed to change output grp-picture (more red,green,....)
char *_tored_,*_togreen_,*_toblue_,*_toblack_,*_towhite_,*_tomono_;

//my palette
char palette[256*3];

//my usercolor
char dependencycolor[256];

//sdl surface
SDL_Surface *sdlsurface;

//key pressed
char keyactive,lastkey;

//active window or not
int active;
//====================================
//set palette now
void activatepallette(char *pal)
{
    SDL_Color rememberpal[256];
     for(int i=0;i<256;i++)
     {
       rememberpal[i].r=pal[i*3+0];
       rememberpal[i].g=pal[i*3+1];
       rememberpal[i].b=pal[i*3+2];
     }
    int err = SDL_SetPalette(sdlsurface,SDL_LOGPAL|SDL_PHYSPAL,rememberpal,0,256);
}
//========================================
//====================================
char *grptexture;
int ctextures;
void loadtexturegrp(void)
{
    GRPFILE *grpmem2;
    int images_tbl,muls,listnr,i;
    if (!grptexture)
    {
        if (loadgrp("texture.grp",&grpmem2))
	{
	    printf("error occured then loading ... file\n");
	    return;	
	}
	GRP_sizexwarppict=grpmem2->SizeX;
	GRP_sizeywarppict=grpmem2->SizeY;
	muls=GRP_sizexwarppict*GRP_sizeywarppict;
	ctextures=grpmem2->CountPictures;
	muls*=ctextures;
	grptexture=(char *)malloc(muls);
	for (i=0;i<ctextures;i++)
	{
	    unpackgrp(0,0,grpmem2,i,grptexture+GRP_sizexwarppict*GRP_sizeywarppict*i);
        }
//	SC_Images_List.FreeAndDelList(listnr,&FreeImagesListData);//no needed packed texture.grp from now
    }
}
//====================================
int LoadingAllPalettes(void)
{
    int i,j;
    //load our palette
    FILE *f = fopen("pal/palette.dat","rb");	
    if (!f)
	printf("file pal/palette.dat not found\n");
    else
    {
	fread(palette,3,256,f);
	fclose(f);
    }
    char *transp = (char *)malloc(256*256);
    //load or create our transparent table from palette
    f = fopen("pal/transptable.dat","rb");
    if (!f)
    {
	printf("file pal/transptable.dat not found\nCreating...");
	fflush(stdout);
	//create transparent table
	CreateTRColors(palette,transp);
	printf("\ndone. now saveing to file pal/transptable.dat\n");
	f = fopen("pal/transptable.dat","wb");
	//save this table to file for future use
	fwrite(transp,256,256,f);
    }
    else
	fread(transp,256,256,f);
    fclose(f);
    //set transparent table to use by grp's function
    SetTranspTable(transp);
    //load user color from file
    f = fopen("pal/usercolor.dat","rb");
    if (!f)
	printf("file pal/usercolor.dat not found\n");
    else
    {
	fread(dependencycolor,1,256,f);
	fclose(f);
        //set 16 usercolors from first 0
	//dependencycolor constain 16*8 bytes
	//and 'SetUserPlayerColors' change 8-15 indexes(pallette remain untouched)
	SetUserPlayerColors(0,16,dependencycolor);
	//set first 16 player colors
    }
    //create black table(for shadows)
    _toblack_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/toblack.grd","rb");	//table of decrement colors(for shadows)
    if (!f)
    {
	printf("file pal/toblack.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(0,0,0),MAKERGB(0,0,0), MAXGRD,_toblack_);
	printf("\ndone. now saveing to file pal/toblack.grd\n");
	f = fopen("pal/toblack.grd","wb");
	fwrite(_toblack_,MAXGRD,256,f);
    }
    else
	fread(_toblack_,MAXGRD,256,f);
    fclose(f);
    
    //create white table(for light if needed)
    
    _towhite_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/towhite.grd","rb");	//table of increment colors up to white
    if (!f)
    {
	printf("file pal/towhite.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(240,240,240),MAKERGB(240,240,240),
		MAXGRD,_towhite_);
	printf("\ndone. now saveing to file pal/towhite.grd\n");
	f = fopen("pal/towhite.grd","wb");
	fwrite(_towhite_,MAXGRD,256,f);
    }
    else
	fread(_towhite_,MAXGRD,256,f);
    fclose(f);

    //create red table(for bloodlust if needed)
    _tored_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/tored.grd","rb");	//table of increment colors up to red
    if (!f)
    {
	printf("file pal/tored.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(120,0,0),MAKERGB(244,228,144),
		MAXGRD,_tored_);
	printf("\ndone. now saveing to file pal/tored.grd\n");
	f = fopen("pal/tored.grd","wb");
	fwrite(_tored_,MAXGRD,256,f);
    }
    else
	fread(_tored_,MAXGRD,256,f);
    fclose(f);
    
    //create green table
    _togreen_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/togreen.grd","rb");	//table of increment colors up to green
    if (!f)
    {
	printf("file pal/togreen.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(0,140,0),MAKERGB(252,252,56),
		MAXGRD,_togreen_);
	printf("\ndone. now saveing to file pal/togreen.grd\n");
	f = fopen("pal/togreen.grd","wb");
	fwrite(_togreen_,MAXGRD,256,f);
    }
    else
	fread(_togreen_,MAXGRD,256,f);
    fclose(f);
    
    //create blue table
    _toblue_ = (char *)malloc(MAXGRD*256);
    f = fopen("pal/toblue.grd","rb");	//table of increment colors up to blue
    if (!f)
    {
	printf("file pal/toblue.grd not found\nCreating...");
	fflush(stdout);
	CreateByRGBTable(palette,MAKERGB(0,60,150),MAKERGB(204,248,248),
		MAXGRD,_toblue_);
	printf("\ndone. now saveing to file pal/toblue.grd\n");
	f = fopen("pal/toblue.grd","wb");
	fwrite(_toblue_,MAXGRD,256,f);
    }
    else
	fread(_toblue_,MAXGRD,256,f);
    fclose(f);

    _tomono_ = (char *)malloc(256);//allocate memory for monocrome table
    
    f = fopen("pal/tomono.grd","rb");	//table of monocrome indexes in same palette
    if (!f)
    {
	printf("file pal/tomono.grd not found\nCreating...");
	fflush(stdout);
	CreateMono(palette,_tomono_);
	printf("\ndone. now saveing to file pal/tomono.grd\n");
	f = fopen("pal/tomono.grd","wb");
	fwrite(_tomono_,1,256,f);
    }
    else
	fread(_tomono_,1,256,f);
    SetPlayerColors(MONOPLAYERCOLOR,1,0,256,_tomono_);
    //set 17-player all 256 colors in mono gradation
    //if on call putgrp's  unitcolor=MONOPLAYERCOLOR we see sprite monocromatic

    fclose(f);
    loadtexturegrp();
    
    return 0;
}

int eventwindowloop(void) //return 1 - need quiting
{
    int keyset=0;
    int exitevent = 0;
    SDL_Event event;
    while ( SDL_PollEvent(&event))
    {
        switch (event.type)
        {
	    case SDL_KEYDOWN:
		keyactive = event.key.keysym.sym;	//memorize key
		lastkey = keyactive;
		keyset=1;
		break;
	    case SDL_KEYUP:
		if (!keyset)
		    keyactive = 0;
		break;
            case SDL_ACTIVEEVENT:			//if window minimize or maximize
                if ( event.active.state & SDL_APPACTIVE )
                {
                    if ( event.active.gain )
                        active = 1;
                    else
                        active = 0;
                }
                break;
            case SDL_QUIT:				//on close event
                exitevent = 1;
                break;
        }
    }
    return (exitevent);
}
//===========================================
int main(int count,char *argv[])
{
    GRPFILE *mygrp;		//need for loadgrp
    if (count != 2)
    {
	printf("usage:%s filename.grp\n",argv[0]);
	return -1;
    }
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER)==-1)
    {
	printf("error initialize sdl\n");
	return -3;
    }
    //set graph mode
    //640x480x8
    sdlsurface = SDL_SetVideoMode(XW,YW,8,SDL_SWSURFACE|SDL_HWPALETTE);
    if (!sdlsurface)
    {
	printf("error to set graph mode\n");
	return -4;
    }
    //now we load pallete and set user colors(8-15 indexes in palette)
    //calculate all tables(glow,shadow,etc..)
    //initialize grp-library with 640x480
    if (InitGrpLib(XW,YW))
    {
	printf("error initialize grplib\n");
	return -1;
    }
    //load grp from file and fill mygrp structure with all grp data

    if (loadgrp(argv[1],&mygrp))
    {
	printf("error occured then loading %s file\n",argv[1]);
	return -2;	
    }
    //sdl initialization
    char fogspr[32*32];
    if (LoadingAllPalettes())
    {
	printf("error to load palettes files\n");
    }
    //set video buffer returned from SDL to use putgrp functions
    SetVideoBuffer(sdlsurface->pixels);//we may call this function any time we need
					//this function change pointer to memory
					//where putgrp's function place sprites
    activatepallette(palette);// set palette (now my window use my palette)

    int exitflag=0,colors=0,gradation=0;
    active = 1;//active window or not
    printf("press \n1/2- to change color of unit\n3/4 - next/prev texture grp\n"
	   "9/0 - +/- gradation intencity(0..%d)\n" 
	   "ESC to exit\n",MAXGRD-1);
    //allocation memory for background , to put fast
    char *background=(char *)malloc(XW*YW);
    
    //set background 
    for (int i=0;i<YW;i++)
        for (int j=0;j<XW;j++)
	    background[i*XW+j]=(char)j;
//	    background[i*XW+j]=(char)0;
    //get size of grp-images
    int xsize = mygrp->SizeX;
    int ysize = mygrp->SizeY;
//    int xsize = mygrp->Picture[0].PixelPerLine;
//    int ysize = mygrp->Picture[0].LinesPerPicture;
    printf("grp with format:\nmax textures=%d\nmaxsizex=%d\nmaxsizey=%d\n",
	    mygrp->CountPictures,xsize,ysize);
    //set first-see values

    int nrsprite = 0,unitcolor=0,grdfactor=MAXGRD/2;
    //now we go in main cycle    

    int warptexture=0;
    do{
	//get key information
	exitflag = eventwindowloop();
	if (exitflag)
	    break;
	if (keyactive=='1')	
	    unitcolor --;	//change unit color
	if (keyactive=='2')
	    unitcolor ++;	//change unit color
	if (unitcolor>ENDPLAYERCOLOR)
	    unitcolor=ENDPLAYERCOLOR;
	if (unitcolor<0)
	    unitcolor=0;
	if (keyactive=='3')	
	    nrsprite--;		//change number of sprite
	if (keyactive=='4')	
	    nrsprite++;		//change number of sprite	
	if (nrsprite<0)
	    nrsprite = 0;
	if (nrsprite>=mygrp->CountPictures)
	    nrsprite = mygrp->CountPictures-1;
	if (keyactive=='0')	
	    grdfactor++;	//change GRADATION
	if (keyactive=='9')
	    grdfactor--;	//change GRADATION
	if (keyactive=='5'){
	    if (--warptexture < 0)
		warptexture++;
	}
	if (keyactive=='6'){
	    if (++warptexture >= ctextures)
		warptexture-- ;
	}
	if (grdfactor<0)	
	    grdfactor=0;
	if (grdfactor>MAXGRD-1)
	    grdfactor=MAXGRD-1;
	if (active)	//if window active, we need to process of update window
	{
	    //print out curent sprites
	    if (keyactive)
	    {
		printf("texture=%d pl_color=%d grd intencity=%d deltax=%d deltay=%d  skipx=%d ,skipy=%d   \xd",
			nrsprite,unitcolor,grdfactor,DELTAX,DELTAY,
			mygrp->Picture[nrsprite].SkipLeft,mygrp->Picture[nrsprite].SkipUp);
		fflush(stdout);
	    }
	    //before use sdl-surface we need to lock them
    	    if (SDL_MUSTLOCK(sdlsurface))
        	SDL_LockSurface(sdlsurface);
	    //put background

	    SetVideoBuffer(sdlsurface->pixels);//we may call this function any time we need

	    memmove((char*)sdlsurface->pixels,background,XW*YW);

	    
	    putgrpwarpfromtext(0,0,mygrp,nrsprite,grptexture + GRP_sizexwarppict*GRP_sizeywarppict*warptexture);
/*
	    putgrpspr(xsize*0-DELTAX,ysize*0-DELTAY,mygrp,NORMAL,0,unitcolor,NULL,nrsprite);
	    iputgrpspr(xsize*1-DELTAX,ysize*1-DELTAY,mygrp,SHADOW,grdfactor,unitcolor,_toblack_,nrsprite);

	    //put totable from grp with gradation
	    putgrpspr(xsize*2-DELTAX,ysize*0-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_toblack_,nrsprite);
	    //put inverted totable from grp with gradation
	    iputgrpspr(xsize*2-DELTAX,ysize*1-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_toblack_,nrsprite);

	    //put totable from grp with gradation
	    putgrpspr(xsize*3-DELTAX,ysize*0-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_towhite_,nrsprite);
	    //put inverted totable from grp with gradation
	    iputgrpspr(xsize*3-DELTAX,ysize*1-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_towhite_,nrsprite);

	    //put transparent grp 50%50
	    //try to change 255 to another value (0-255) :)
	    //		********************************
	    //		********************************
	    //		********************************
	    putgrpspr(xsize*3-DELTAX,ysize*2-DELTAY,mygrp,TRANSPARENT,255,unitcolor,NULL,nrsprite);

	    //put inverted transparent grp 50%50 
	    iputgrpspr(xsize*3-DELTAX,ysize*3-DELTAY,mygrp,TRANSPARENT,255,unitcolor,NULL,nrsprite);

	    //put distortioned grp (like an invisible PREDATOR from movie)
	    putgrpspr(xsize*0-DELTAX,ysize*4-DELTAY,mygrp,DISTORTION,255,unitcolor,NULL,nrsprite);

	    //put inverted distortioned grp 
	    iputgrpspr(xsize*0-DELTAX,ysize*5-DELTAY,mygrp,DISTORTION,255,unitcolor,NULL,nrsprite);
	    
	    //put totable from grp with gradation
	    putgrpspr(xsize*0-DELTAX,ysize*2-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_tored_,nrsprite);

	    //put inverted totable from grp with gradation
	    iputgrpspr(xsize*0-DELTAX,ysize*3-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_tored_,nrsprite);

	    putgrpspr(xsize*1-DELTAX,ysize*2-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_togreen_,nrsprite);

	    //put inverted totable from grp with gradation
	    iputgrpspr(xsize*1-DELTAX,ysize*3-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_togreen_,nrsprite);

	    putgrpspr(xsize*2-DELTAX,ysize*2-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_toblue_,nrsprite);

	    //put inverted totable from grp with gradation
	    iputgrpspr(xsize*2-DELTAX,ysize*3-DELTAY,mygrp,TOTABLE,grdfactor,unitcolor,_toblue_,nrsprite);

	    putgrpwarpfromtext(xsize*1-DELTAX,ysize*4-DELTAY,mygrp,nrsprite,grptexture);
*/
	    
//	    putsprgrd(600-DELTAX,440-DELTAY,fogspr,_toblack_);
//	    putsprgrd(-1,-1,fogspr,_toblack_);

	    if (SDL_MUSTLOCK(sdlsurface))
    		SDL_UnlockSurface(sdlsurface);
	    //update screen
	    SDL_UpdateRect(sdlsurface, 0, 0, 0, 0);
//	    getchar();
	  }
	//forgot key press
	keyactive = 0;
    }while(lastkey!=SDLK_ESCAPE);  //exit if escape pressed

    free(background);		 //free memory allocated for background
    freegrp(mygrp);		 //free memory allocated by loadgrp	
    QuitGrpLib();		 //exit grplib
    SDL_Quit();
    return 0;
}


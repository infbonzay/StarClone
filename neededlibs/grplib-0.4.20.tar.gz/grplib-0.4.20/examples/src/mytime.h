#if !defined(_MYTIME_W)
#define _MYTIME_W 1

    void getusec(long *sec,long *microsec);
    long long getmicrosecs(void);

#endif


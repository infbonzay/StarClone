#include <stdlib.h>
    #include <sys/time.h>
    void getusec(long *sec,long *microsec)      //get microseconds
    {
        struct timeval tv;
        gettimeofday(&tv,NULL);
        *sec = tv.tv_sec;
        *microsec = tv.tv_usec;
    }

long long getmicrosecs(void)
{
    long sec,usec;
    getusec(&sec,&usec);
    return(((long long) sec) * 1000000L + usec);
}

